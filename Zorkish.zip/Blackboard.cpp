#include "Blackboard.h"

using namespace std;

Blackboard::Blackboard()
{
}

void Blackboard::Add(Message message)
{
	messages.push(message);
}

void Blackboard::Remove()
{
	messages.pop();
}

void Blackboard::Run()
{
	messages.front().Run();
	messages.pop();
}

void Blackboard::RunAll()
{
	while (messages.size() > 0)
	{
		messages.front().Run();
		messages.pop();
	}
}