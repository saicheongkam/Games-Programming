#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include "Item.h"
#include "Enemy.h"

class Node
{
private:

public:
	std::string connection;
	std::string id;
	std::string name;
	std::string description;
	Node* north;
	Node* east;
	Node* south;
	Node* west;
	Node* up;
	Node* down;

	std::map<std::string, Thing*> inventory;
	std::map<std::string, Enemy> enemies;

	Node();
	Node(std::string id, std::string name, std::string desc, std::string go);
	
	void SetItem(std::map<std::string, Thing*>& inventory, int line);
	void SetEnemy(std::map<std::string, Enemy>& enemies, int line);

	void Display();
	void PrintInventory();
	void PrintEnemies();
};


class Graph
{
public:
	std::map<int, Node> nodes;
	Graph();
	Graph(std::string world);
	Node SetLocation(std::string world, int line);
	void SetConnection(Node node, std::map<int, Node> nodes);
};


