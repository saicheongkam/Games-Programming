#include "Message.h"

using namespace std;

Message::Message()
{
	id = 0;
}

Message::Message(Player& send, Enemy& receive, string typ, int dta)
{
	id = 1;
	pSender = send;
	eReceiver = receive;
	type = typ;
	data = dta;
}

Message::Message(Enemy& send, Player& receive, string typ, int dta)
{
	id = 2;
	eSender = send;
	pReceiver = receive;
	type = typ;
	data = dta;
}

Message::Message(Thing* send, Enemy& receive, string typ, int dta)
{
	id = 3;
	tSender = send;
	eReceiver = receive;
	type = typ;
	data = dta;
}

void Message::Run()
{
	if (id == 1)
		PlayerEnemyRun();
	else if (id == 2)
		EnemyPlayerRun();
	else if (id == 3)
		ThingEnemyRun();
}

void Message::PlayerEnemyRun()
{
	pSender.RunMessage();
	eReceiver.RunMessage(type, data);
}

void Message::EnemyPlayerRun()
{
	pReceiver.RunMessage(type, data);
}

void Message::ThingEnemyRun()
{
	tSender->RunMessage();
	eReceiver.RunMessage(type, data);
}