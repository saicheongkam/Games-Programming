#include "Announcement.h"

using namespace std;

Announcement::Announcement()
{
}

Announcement::Announcement(Player& sender, vector<Enemy> receiver, string type, int data)
{
	for (vector<Enemy>::iterator &it = receiver.begin(); it != receiver.end(); ++it)
		Message(sender, *it, type, data).Run();
}

Announcement::Announcement(Thing* sender, vector<Enemy> receiver, string type, int data)
{
	for (vector<Enemy>::iterator it = receiver.begin(); it != receiver.end(); ++it)
		Message(sender, *it, type, data).Run();
}