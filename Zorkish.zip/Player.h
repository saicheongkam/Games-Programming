#pragma once

#include "Graph.h"
#include "Item.h"
#include <string>
#include <map>

class Player
{
public:
	Node location;
	std::map<std::string, Component*> components;
	Player();

	void Attack();
	void Attacked(int damage);

	std::map<std::string, Thing*> Inventory;
	void PrintInventory();

	void RunMessage();
	void RunMessage(std::string type, int data);
};