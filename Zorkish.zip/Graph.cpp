#include "Graph.h"
#include <iostream>

using namespace std;

Node::Node()
{
	id = "0";
	name = "";
	description = "";
}

Node::Node(string idNo, string nme, string desc, string go)
{
	id = idNo;
	name = nme;
	description = desc;
	connection = go;

	inventory = map<string, Thing*>();

	north = new Node();
	east = new Node();
	south = new Node();
	west = new Node();
	up = new Node();
	down = new Node();
}

void Node::SetItem(map<string, Thing*>& inventory, int line)
{
	int rowCount = 0;
	string name;
	string desc;
	string damage;

	ifstream file;
	file.open("Grass World Items.txt", ifstream::in);

	while (!file.eof())
	{
		if (rowCount < line)
		{
			getline(file, name, '\n');
			getline(file, name, ',');
			getline(file, desc, ',');
			getline(file, damage, ',');
			rowCount++;

			if (rowCount < line)
			{
				name = "";
				desc = "";
				damage = "";
			}
		}
		else
			break;
	}
	if ((int)damage[0] - 48 > 0)
	{
		inventory[name] = new Weapon(name, desc);
		inventory[name]->components["damage"]->damage = (int)damage[0] - 48;
	}
	else
		inventory[name] = new Thing(name, desc);
	file.close();
}

void Node::SetEnemy(map<string, Enemy>& enemies, int line)
{
	int rowCount = 0;
	string name;
	string desc;
	string health;

	ifstream file;
	file.open("Grass World Enemies.txt", ifstream::in);

	while (!file.eof())
	{
		if (rowCount < line)
		{
			getline(file, name, '\n');
			getline(file, name, ',');
			getline(file, desc, ',');
			getline(file, health, ',');
			rowCount++;

			if ((name != "") && (desc != "") && (health != ""))
				enemies[name] = Enemy(name, desc, (int)health[0] - 48);

			if (rowCount < line)
			{
				name = "";
				desc = "";
				health = "";
			}

		}
		else
			break;
	}
	if ((name != "") && (desc != "") && (health != ""))
		enemies[name] = Enemy(name, desc, (int)health[0] - 48);

	file.close();
}

void Node::Display()
{
	cout << name << "\n" << description << endl << endl;
}

void Node::PrintInventory()
{
	if (inventory.size() != 0)
	{
		cout << "This place contains: " << endl;
		for (map<string, Thing*>::iterator it = inventory.begin(); it != inventory.end(); ++it)
		{
			it->second->PrintName();
			it->second->PrintDesc();
			cout << endl;
		}
	}
	else
		cout << "There is nothing particularly useful in this location\n";
}

void Node::PrintEnemies()
{
	if (enemies.size() != 0)
	{
		for (map<string, Enemy>::iterator it = enemies.begin(); it != enemies.end(); ++it)
		{
			it->second.PrintDesc();
			cout << endl;
		}
	}
}

Graph::Graph()
{
}

Graph::Graph(string world)
{
	string worldDesc;

	ifstream file;

	file.open(world + ".txt", ifstream::in);

	getline(file, worldDesc, ',');
	cout << worldDesc << endl;
	getline(file, worldDesc, ',');
	cout << worldDesc;

	Node loc1 = SetLocation(world, 1);
	Node loc2 = SetLocation(world, 2);
	Node loc3 = SetLocation(world, 3);
	Node loc4 = SetLocation(world, 4);

	nodes[1] = loc1;
	nodes[2] = loc2;
	nodes[3] = loc3;
	nodes[4] = loc4;

	SetConnection(loc1, nodes);
	SetConnection(loc2, nodes);
	SetConnection(loc3, nodes);
	SetConnection(loc4, nodes);

	file.close();
}

Node Graph::SetLocation(string world, int line)
{
	string id;
	string name;
	string desc;
	string go;
	Node node;

	int rowCount = 0;

	ifstream file;
	file.open(world + ".txt", ifstream::in);
	while (!file.eof())
	{
		if (rowCount < line)
		{
			getline(file, id, '\n');
			getline(file, id, ',');
			getline(file, name, ',');
			getline(file, desc, ',');
			getline(file, go, ',');
			rowCount++;

			if (rowCount < line)
			{
				id = "";
				name = "";
				desc = "";
				go = "";
			}
		}
		else
			break;
	}

	node = Node(id, name, desc, go);
	node.SetItem(node.inventory, line);
	node.SetEnemy(node.enemies, line);

	return node;
}

void Graph::SetConnection(Node node, map<int, Node> nodes)
{
	if (node.connection.size() >= 2)
	{	
		switch (node.connection[0])					//Gets the character that defines the direction of the first connection
		{
		case 'N':
			*node.north = nodes[(int)node.connection[1]-48];	//Gets the interger that defines the id of the connecting node
			break;
		case 'E':
			*node.east = nodes[(int)node.connection[1]-48];
			break;
		case 'S':
			*node.south = nodes[(int)node.connection[1]-48];
			break;
		case 'W':
			*node.west = nodes[(int)node.connection[1]-48];
			break;
		case 'U':
			*node.up = nodes[(int)node.connection[1]-48];
			break;
		case 'D':
			*node.down = nodes[(int)node.connection[1]-48];
			break;
		default:
			break;
		}
	}

	if (node.connection.size() >= 4)
	{
		switch (node.connection[2])					//Gets the character that defines the direction of the second connection
		{
		case 'N':
			*node.north = nodes[(int)node.connection[3]-48];	//Gets the interger that defines the id of the connecting node
			break;
		case 'E':
			*node.east = nodes[(int)node.connection[3]-48];
			break;
		case 'S':
			*node.south = nodes[(int)node.connection[3]-48];
			break;
		case 'W':
			*node.west = nodes[(int)node.connection[3]-48];
			break;
		case 'U':
			*node.up = nodes[(int)node.connection[3]-48];
			break;
		case 'D':
			*node.down = nodes[(int)node.connection[3]-48];
			break;
		default:
			break;				//Does nothing if there is no second connection
		}
	}

	if (node.connection.size() >= 6)
	{
		switch (node.connection[4])					//Gets the character that defines the direction of the third connection
		{
		case 'N':
			*node.north = nodes[(int)node.connection[5]-48];	//Gets the interger that defines the id of the connecting node
			break;
		case 'E':
			*node.east = nodes[(int)node.connection[5]-48];
			break;
		case 'S':
			*node.south = nodes[(int)node.connection[5]-48];
			break;
		case 'W':
			*node.west = nodes[(int)node.connection[5]-48];
			break;
		case 'U':
			*node.up = nodes[(int)node.connection[5]-48];
			break;
		case 'D':
			*node.down = nodes[(int)node.connection[5]-48];
			break;
		default:
			break;			//Does nothing if there is no third connection
		}
	}
}
