#include "Item.h"
#include "Message.h"

using namespace std;

Thing::Thing()
{
	name = "";
	description = "";
}

Thing::Thing(string nme, string desc)
{
	name = nme;
	description = desc;
}

void Thing::PrintName()
{
	cout << name << endl;
}

void Thing::PrintDesc()
{
	cout << description << endl;
}

void Thing::Attack()
{
}

void Thing::PrintInventory()
{
}

void Thing::RunMessage()
{
}

Item::Item(string nme, string desc) : Thing(nme, desc)
{
}

Weapon::Weapon() : Thing()
{
	components["damage"] = new DamageComponent();
}

Weapon::Weapon(string nme, string desc) : Thing(nme, desc)
{
	components["damage"] = new DamageComponent();
}

void Weapon::Attack()
{
	components["damage"]->Attack(name);
}

void Weapon::RunMessage()
{
	Attack();
}

Bag::Bag(string nme, string desc) : Thing(nme, desc)
{
}

void Bag::PrintInventory()
{
	if (Thing::inventory.size() != 0)
	{
		cout << "\nThis bag contains:" << endl;
		for (map<string, Thing*>::iterator it = Thing::inventory.begin(); it != Thing::inventory.end(); ++it)
		{
			it->second->PrintName();
			it->second->PrintDesc();
			cout << endl;
		}
	}
	else
		cout << "The bag is empty\n";
}