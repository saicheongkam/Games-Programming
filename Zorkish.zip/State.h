#pragma once

#include "Player.h"
#include <string>

class State
{
protected:
	std::string input;
	State* stateChange;

public:
	State();
	State* StateChange();
	virtual void Run();
};	

class StateManager
{
private:
	State* currentState;

public:
	StateManager();
};

class MainMenu : public State
{
public:
	MainMenu();
	void Run() override;
};

class About : public State
{
private:
	bool back;
public:
	About();
	void Run() override;
};

class Help : public State
{
private:
	bool back;
public:
	Help();
	void Run() override;
};

class SelectAdventure : public State
{
public:
	SelectAdventure();
	void Run() override;
};

class Gameplay : public State
{
public:
	Player player;
	Gameplay();
	void Run() override;
};

class ViewHOF : public State
{
private:
	bool back;
public:
	ViewHOF();
	void Run() override;
};

class NewHighScore : public State
{
public:
	NewHighScore();
	void Run() override;
};
