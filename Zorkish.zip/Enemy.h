#pragma once

#include "ComponentManager.h"
#include <iostream>
#include <string>
#include <map>

class Enemy
{
private:

public:
	std::string name;
	std::string description;
	std::map<std::string, Component*> components;

	Enemy();
	Enemy(std::string name, std::string desc, int health);

	void PrintDesc();
	void Attacked(int damage);

	void RunMessage(std::string type, int data);
};