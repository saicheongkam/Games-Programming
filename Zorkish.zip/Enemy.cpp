#include "Enemy.h"

using namespace std;

Enemy::Enemy()
{
	name = "";
	description = "";
	components["attackable"] = new AttackableComponent(0);
}

Enemy::Enemy(string nme, string desc, int health)
{
	name = nme;
	description = desc;
	components["attackable"] = new AttackableComponent(health);
}

void Enemy::Attacked(int damage)
{
	components["attackable"]->Attacked(damage);
}

void Enemy::PrintDesc()
{
	cout << description << endl;
}

void Enemy::RunMessage(string type, int data)
{
	if (type == "damage")
		Attacked(data);	
}