#pragma once

#include "ComponentManager.h"
#include <iostream>
#include <string>
#include <map>

class Thing
{
private:
	
public:
	std::string name;
	std::string description;
	std::map<std::string, Component*> components;

	Thing();
	Thing(std::string name, std::string desc);
	virtual void PrintName();
	virtual void PrintDesc();
	virtual void Attack();

	std::map<std::string, Thing*> inventory;
	virtual void PrintInventory();

	virtual void RunMessage();
};

class Item : virtual public Thing
{
private:

public:
	Item();
	Item(std::string name, std::string desc);

	void PrintName() override
	{
		Thing::PrintName();
	}
	void PrintDesc() override
	{
		Thing::PrintDesc();
	}
};

class Weapon : virtual public Thing
{
private:

public:
	Weapon();
	Weapon(std::string name, std::string desc);

	void PrintName() override
	{
		Thing::PrintName();
	}
	void PrintDesc() override
	{
		Thing::PrintDesc();
	}

	void Attack() override;

	void RunMessage() override;
};

class Bag : public Thing
{
private:

public:
	Bag();
	Bag(std::string name, std::string desc);

	void PrintName() override
	{
		Thing::PrintName();
	}
	void PrintDesc() override
	{
		Thing::PrintDesc();
	}

	std::map<std::string, Thing*> inventory;
	virtual void PrintInventory();
};