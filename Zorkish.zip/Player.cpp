#include "Player.h"

using namespace std;

Player::Player()
{
	Thing* bag = new Bag("bag", "A small bag tied closed with some string");
	Thing* rock = new Weapon("rock", "a rock the size of your palm");
	
	bag->inventory["rock"] = rock;
	Inventory["bag"] = bag;

	components["attackable"] = new AttackableComponent(10);
}

void Player::Attack()
{
	cout << "You go for a punch and land it right in its face. You dealt 1 damage\n";
}

void Player::Attacked(int damage)
{
	components["attackable"]->PlayerAttacked(damage);
}

void Player::PrintInventory()
{
	if (Inventory.size() != 0)
	{
		cout << "Your inventory contains:" << endl;
		for (map<string, Thing*>::iterator it = Inventory.begin(); it != Inventory.end(); ++it)
		{
			it->second->PrintName();
			it->second->PrintDesc();
			cout << endl;
		}
	}
	else
		cout << "Your inventory is empty\n";
}

void Player::RunMessage()
{
	Attack();
}

void Player::RunMessage(string type, int data)
{
	cout << "It fights back, landing a hit on you and dealing " << data << " damage\n";

	if (type == "damage")
		Attacked(data);	
}