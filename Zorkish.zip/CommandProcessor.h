#pragma once

#include "Message.h"
#include "Announcement.h"
#include "Blackboard.h"
#include "Player.h"
#include "Enemy.h"
#include <string>
#include <iostream>
#include <vector>

class Command
{
public:
	std::vector<std::string> words;
	Blackboard blackboard;

	Command();
	Command(std::string first);
	virtual void Execute(Player& p, std::string text[]);
};

class GoCommand : virtual public Command
{
public:
	GoCommand(std::string first);
	void Execute(Player& p, std::string text[]) override;
};

class LookCommand : virtual public Command
{
public:
	LookCommand(std::string first);
	void Execute(Player& p, std::string text[]) override;
	void LookAtIn(Player& p, std::string object, std::string container);
};

class TakeCommand : virtual public Command
{
public:
	TakeCommand(std::string first);
	void Execute(Player& p, std::string text[]) override;
	void TakeFrom(Player& p, std::string object, std::string container);
};

class PutCommand : virtual public Command
{
public:
	PutCommand(std::string first);
	void Execute(Player& p, std::string text[]) override;
	void Put(Player& p, std::string object, std::string container);
};

class DropCommand : virtual public Command
{
public:
	DropCommand(std::string first);
	void Execute(Player& p, std::string text[]) override;
	void Drop(Player& p, std::string object);
};

class AttackCommand : virtual public Command
{
public:
	AttackCommand(std::string first);
	void Execute(Player& p, std::string text[]) override;
	void AttackWith(Player& p, std::string enemy, std::string object);
};

class CommandProcessor
{
private:
	std::vector<Command*> commands;

public:
	CommandProcessor();

	void Execute(Player& p, std::string text[]);
};