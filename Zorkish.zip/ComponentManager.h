#pragma once

#include <iostream>
#include <string>

class Component
{
private:

public:
	int damage;
	int health;
	bool alive;

	Component();
	virtual void Attack(std::string name);
	virtual void Attacked(int damage);
	virtual void PlayerAttacked(int damage);
};

class DamageComponent : virtual public Component
{
private:

public:
	DamageComponent();
	void Attack(std::string name) override;
};

class AttackableComponent : virtual public Component
{
private:

public:
	AttackableComponent();
	AttackableComponent(int health);
	void Attacked(int damage) override;
	void PlayerAttacked(int damage) override;
};