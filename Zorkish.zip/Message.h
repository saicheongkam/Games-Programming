#pragma once

#include "Item.h"
#include "Player.h"
#include "Enemy.h"
#include <iostream>
#include <string>


class Message
{
private:
	int id;
	Player pSender;
	Player pReceiver;
	Thing* tSender;
	Enemy eSender;
	Enemy eReceiver;
	std::string type;
	int data;

public:
	
	Message();
	Message(Player& sender, Enemy& receiver, std::string type, int data);
	Message(Enemy& sender, Player& receiver, std::string type, int data);
	Message(Thing* sender, Enemy& receiver, std::string type, int data);

	void Run();
	void PlayerEnemyRun();
	void EnemyPlayerRun();
	void ThingEnemyRun();
};