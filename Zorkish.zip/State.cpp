#include "State.h"
#include "Graph.h"
#include "CommandProcessor.h"
#include <iostream>
#include <conio.h>

using namespace std;

StateManager::StateManager()
{
	State* currentState = new MainMenu();
	while (true)
	{
		currentState->Run();
		currentState = currentState->StateChange();
	}
}

State::State()
{
}

State* State::StateChange()
{
	return stateChange;
}

void State::Run()
{
}


MainMenu::MainMenu()
{
}

void MainMenu::Run()
{
	cout << "Zorkish :: Main Menu" << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << endl;
	cout << "Welcome to Zorkish Adventures" << endl;
	cout << "\t" << "1. Select Adventure and Play" << endl;
	cout << "\t" << "2. Hall of Fame" << endl;
	cout << "\t" << "3. Help" << endl;
	cout << "\t" << "4. About" << endl;
	cout << "\t" << "5. Quit" << endl;
	cout << endl;
	cout << "Select 1-5: " << endl;

	while ((input != "1") && (input != "2") && (input != "3") && (input != "4") && (input != "5"))
		cin >> input;

	if (input == "1")
		this->stateChange = new SelectAdventure();
	else if (input == "2")
		this->stateChange = new ViewHOF();
	else if (input == "3")
		this->stateChange = new Help();
	else if (input == "4")
		this->stateChange = new About();
	else if (input == "5")
		exit(0);

	input = "";
}


About::About()
{
	back = false;
}

void About::Run()
{
	cout << "Zorkish :: About" << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << endl;
	cout << "Written By: Sai Cheong Kam" << endl;
	cout << endl;
	cout << "Press ESC or Enter to return to the Main Menu" << endl;

	while (back == false)
	{
		char key = getch();
		if ((key == 27) || (key == 13))
			back = true;
	}

	this->stateChange = new MainMenu();
}


Help::Help()
{
	back = false;
}

void Help::Run()
{
	cout << "Zorkish :: Help" << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << endl;
	cout << "The following commands are supported:" << endl;
	cout << endl;
	cout << "\t" << "quit" << endl;
	cout << "\t" << "go _" << endl;
	cout << "\t" << "look at _ (in _) " << endl;
	cout << "\t" << "look in _" << endl;
	cout << "\t" << "take _ (from _)" << endl;
	cout << "\t" << "drop _" << endl;
	cout << "\t" << "attack _ (with _)" << endl;
	cout << "Press ESC or Enter to return to the Main Menu" << endl;

	while (back == false)
	{
		char key = getch();
		if ((key == 27) || (key == 13))
			back = true;
	}

	this->stateChange = new MainMenu();
}


SelectAdventure::SelectAdventure()
{
}

void SelectAdventure::Run()
{
	cout << "Zorkish :: Select Adventure" << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << endl;
	cout << "Choose your adventure" << endl;
	cout << endl;
	cout << "\t" << "1. Grass World" << endl;
	cout << "\t" << "2. Stone World" << endl;
	cout << "\t" << "3. Box World" << endl;
	cout << endl;
	cout << "Select 1-3: " << endl;

	while ((input != "1") && (input != "2") && (input != "3"))
		cin >> input;

	if ((input == "1") || (input == "2") || (input == "3"))
		this->stateChange = new Gameplay();

	input = "";
}


Gameplay::Gameplay()
{
}

void Gameplay::Run()
{
	Graph graph = Graph("Grass World");
	CommandProcessor cp;
	string word[5];
	int i = 0;
	player.location = graph.nodes[1];

	cout << endl << endl;
	player.location.Display();

	while ((input != "quit") && (input != "hiscore"))
	{
		cout << ":> ";
		getline(cin, input);

		for (string::iterator it = input.begin(); it != input.end(); ++it)
		{
			if (*it != char(32))
				word[i] += *it;
			else if (*it == char(32))
			{
				i++;
			}
		}

		cout << endl;
		cp.Execute(player, word);
		word[0] = "";
		word[1] = "";
		word[2] = "";
		word[3] = "";
		word[4] = "";
		i = 0;
	}

	if (input == "quit")
	{
		cout << "Your adventure has ended without fame or fortune." << endl;
		this->stateChange = new MainMenu();
	}
	else if (input == "hiscore")
	{
		cout << "You have entered the magic word and will now see the \"New High Score\" screen." << endl;
		this->stateChange = new NewHighScore();
	}

	input = "";
}



ViewHOF::ViewHOF()
{
	back = false;
}

void ViewHOF::Run()
{
	cout << "Zorkish :: Hall Of Fame" << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << endl;
	cout << "Top 10 Zorkish Champions" << endl;
	cout << endl;
	cout << "\t" << "1. Fred, Mountain World, 5000" << endl;
	cout << "\t" << "2. Mary, Mountain World, 4000" << endl;
	cout << "\t" << "3. Jow, Water World, 3000" << endl;
	cout << "\t" << "4. Henry, Mountain World, 2000" << endl;
	cout << "\t" << "5. Susan, Mountain World, 1000" << endl;
	cout << "\t" << "6. Alfred, Water World, 900" << endl;
	cout << "\t" << "7. Clark, Mountain World, 800" << endl;
	cout << "\t" << "8. Harold, Mountain World, 500" << endl;
	cout << "\t" << "9. Julie, Water World, 300" << endl;
	cout << "\t" << "10. Bill, Box World, -5" << endl;
	cout << endl;
	cout << "Press ESC or Enter to return to the Main Menu" << endl;

	while (back == false)
	{
		char key = getch();
		if ((key == 27) || (key == 13))
			back = true;
	}

	this->stateChange = new MainMenu();
}


NewHighScore::NewHighScore()
{
}

void NewHighScore::Run()
{
	cout << "Zorkish :: New High Score" << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << endl;
	cout << "Congratulations!" << endl;
	cout << endl;
	cout << "You have made it to the Zorkish Hall Of Fame" << endl;
	cout << "\t" << "Adventure: " << endl;
	cout << "\t" << "Score: " << endl;
	cout << "\t" << "Moves: " << endl;
	cout << endl;
	cout << "Please type your name and press Enter:" << endl;

	cin >> input;

	input = "";

	this->stateChange = new MainMenu();
}