#include "ComponentManager.h"

using namespace std;

Component::Component()
{
}

void Component::Attack(string name)
{
}

void Component::Attacked(int damage)
{
}

void Component::PlayerAttacked(int damage)
{
}

DamageComponent::DamageComponent()
{
	damage = 2;
}

void DamageComponent::Attack(string name)
{
	if (name == "sword")
		cout << "You swing your sword and hit. You dealt " << damage << " damage\n";
	if (name == "axe")
		cout << "You swing your axe hard and decapitate it. You dealt " << damage << " damage\n";
	if (name == "rock")
		cout << "You hold your rock and slam it into its head. You dealt " << damage << " damage\n";
}

AttackableComponent::AttackableComponent()
{
	alive = true;
	health = 3;
}

AttackableComponent::AttackableComponent(int healthPts)
{
	health = healthPts;
	alive = true;
}

void AttackableComponent::Attacked(int damage)
{
	health -= damage;
	
	if (health < 1)
	{
		alive = false;
		cout << "You have slain the monster\n";
	}
}

void AttackableComponent::PlayerAttacked(int damage)
{
	health -= damage;
	
	if (health < 1)
	{
		alive = false;
		cout << "YOU HAVE DIED!\n";
	}
}