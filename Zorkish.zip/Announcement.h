#pragma once

#include "Message.h"
#include <vector>

class Announcement
{
private:
	std::vector<Message> messages;
public:
	Announcement();
	Announcement(Player& sender, std::vector<Enemy> receiver, std::string type, int data);
	Announcement(Thing* sender, std::vector<Enemy> receiver, std::string type, int data);
};