#include "State.h"
#include "Graph.h"
#include "Player.h"
#include "Message.h"
#include <iostream>

using namespace std;

static StateManager stateManager;
static Player player;

int main()
{
}