#pragma once

#include "Message.h"
#include "Announcement.h"
#include <queue>

class Blackboard
{
private:
	std::queue<Message> messages;
public:
	Blackboard();

	void Add(Message message);
	void Remove();
	void Run();
	void RunAll();
};