#include "CommandProcessor.h"
#include <ctime>

using namespace std;

Command::Command()
{
}

Command::Command(string first)
{
}

void Command::Execute(Player& p, string text[])
{
}

GoCommand::GoCommand(string first)
{
	words.resize(2);
	words[0] = first;
}

void GoCommand::Execute(Player& p, string text[])
{
	if (text[0] == "go")
	{
		if ((text[1] == "n") || (text[1] == "north"))
		{
			if (p.location.north->id != "0")
				p.location = *p.location.north;
			else
			{
				cout << "You cannot go north from here\n\n";
			}
		}
		else if ((text[1] == "e") || (text[1] == "east"))
		{
			if (p.location.east->id != "0")
				p.location = *p.location.east;
			else
			{
				cout << "You cannot go east from here\n\n";
			}
		}
		else if ((text[1] == "s") || (text[1] == "south"))
		{
			if (p.location.south->id != "0")
				p.location = *p.location.south;
			else
			{
				cout << "You cannot go south from here\n\n";
			}
		}
		else if ((text[1] == "w") || (text[1] == "west"))
		{
			if (p.location.west->id != "0")
				p.location = *p.location.west;
			else
			{
				cout << "You cannot go west from here\n\n";
			}
		}
		else if ((text[1] == "u") || (text[1] == "up"))
		{
			if (p.location.up->id != "0")
				p.location = *p.location.up;
			else
			{
				cout << "You cannot go up from here\n\n";
			}
		}
		else if ((text[1] == "d") || (text[1] == "down"))
		{
			if (p.location.down->id != "0")
				p.location = *p.location.down;
			else
			{
				cout << "You cannot go down from here\n\n";
			}
		}
		else
		{
			cout << "Invalid Command\n";
		}
	}
	else
	{
		if ((text[0] == "n") || (text[0] == "north"))
		{
			if (p.location.north->id != "0")
				p.location = *p.location.north;
			else
			{
				cout << "You cannot go north from here\n\n";
			}
		}
		else if ((text[0] == "e") || (text[0] == "east"))
		{
			if (p.location.east->id != "0")
				p.location = *p.location.east;
			else
			{
				cout << "You cannot go east from here\n\n";
			}
		}
		else if ((text[0] == "s") || (text[0] == "south"))
		{
			if (p.location.south->id != "0")
				p.location = *p.location.south;
			else
			{
				cout << "You cannot go south from here\n\n";
			}
		}
		else if ((text[0] == "w") || (text[0] == "west"))
		{
			if (p.location.west->id != "0")
				p.location = *p.location.west;
			else
			{
				cout << "You cannot go west from here\n\n";
			}
		}
		else if ((text[0] == "u") || (text[0] == "up"))
		{
			if (p.location.up->id != "0")
				p.location = *p.location.up;
			else
			{
				cout << "You cannot go up from here\n\n";
			}
		}
		else if ((text[0] == "d") || (text[0] == "down"))
		{
			if (p.location.down->id != "0")
				p.location = *p.location.down;
			else
			{
				cout << "You cannot go down from here\n\n";
			}
		}
		else if (text[0] != "")
		{
			cout << "Invalid Command\n";
		}
	}

	cout << endl;
	p.location.Display();
	p.location.PrintEnemies();
}

LookCommand::LookCommand(string first)
{
	words.resize(5);
	words[0] = first;
}

void LookCommand::Execute(Player& p, string text[])
{
	if (text[1] == "at") 
	{
		if ((text[2] != "inventory") && (text[2] != ""))
		{
			if (text[3] != "in")
				LookAtIn(p, text[2], "location");		//look at (item)
			else
			{
				if (text[4] != "")
					LookAtIn(p, text[2], text[4]);		//look at (item) in (container)
				else
					cout << "Invalid Command\n";
			}
		}
		else if (text[2] == "inventory")
			LookAtIn(p, "", "inventory");
		else if (text[2] == "bag")
			LookAtIn(p, "bag", "location");
		else
			cout << "Invalid Command\n";
	}
	else if (text [1] == "in")
	{
		if (text[2] == "inventory")
			LookAtIn(p, "", "inventory");
		else if (text[2] == "bag")
			LookAtIn(p, "bag", "inventory");
		else
			cout << "Invalid Command\n";
	}
	else
		cout << "Invalid Command\n";
}

void LookCommand::LookAtIn (Player& p, string object, string container)
{
	if (object == "location")
		p.location.PrintInventory();
	else if (object == "bag")
	{
		if (container == "inventory")
		{
			if (p.Inventory.find("bag") != p.Inventory.end())
			{
				p.Inventory["bag"]->PrintName();
				p.Inventory["bag"]->PrintDesc();
				p.Inventory["bag"]->PrintInventory();
			}
			else
				cout << "There is no bag in your inventory\n";
		}
		else if (container == "location")
		{
			if (p.location.inventory.find("bag") != p.location.inventory.end())
			{
				p.location.inventory["bag"]->PrintName();
				p.location.inventory["bag"]->PrintDesc();	
			}
			else
				cout << "There is no bag here\n";
		}
	}
	else if (container == "location")
	{
		if (p.location.inventory.find(object) != p.location.inventory.end())
		{
			p.location.inventory[object]->PrintName();
			p.location.inventory[object]->PrintDesc();
		}
		else
			cout << "There is no " + object + " here\n";
	}
	else if (container == "inventory")
	{
		if (object == "")
			p.PrintInventory();
		else if (p.Inventory.find(object) != p.Inventory.end())
			p.Inventory[object]->PrintDesc();
		else
			cout << "There is no " + object + " in your inventory\n";
	}
	else if (container == "bag")
	{
		if (p.Inventory.find("bag") != p.Inventory.end())
		{
			if (p.Inventory["bag"]->inventory.find(object) != p.Inventory["bag"]->inventory.end())
			{
				p.Inventory["bag"]->inventory[object]->PrintName();
				p.Inventory["bag"]->inventory[object]->PrintDesc();
			}
			else
				cout << "You do not have a " + object + " in your bag\n";
		}
		else
			cout << "You do not have a bag\n";
	}
	else
		cout << "You cannot look in that\n";

	cout << endl;
}

TakeCommand::TakeCommand(string first)
{
	words.resize(4);
	words[0] = first;
}

void TakeCommand::Execute(Player& p, string text[])
{
	if ((text[1] != "from") && (text[1] != ""))
	{
		if (text[2] != "from")
			TakeFrom(p, text[1], "location");
		else
		{
			if (text[3] != "")
				TakeFrom(p, text[1], text[3]);
			else
				cout << "Invalid Command\n";
		}
	}
	else
		cout << "Invalid Command\n";
}

void TakeCommand::TakeFrom(Player& p, string object, string container)
{
	if (container == "location")
	{
		if (p.location.inventory.find(object) != p.location.inventory.end())
		{
			p.Inventory[object] = p.location.inventory[object];
			p.location.inventory.erase(object);
			cout << "You have taken a " + object + "\n";
		}
		else
			cout << "There is no " + object + " here\n";
	}
	else if (container == "bag")
	{
		if (p.Inventory.find("bag") != p.Inventory.end())
		{
			if (p.Inventory["bag"]->inventory.find(object) != p.Inventory["bag"]->inventory.end())
			{
				p.Inventory[object] = p.Inventory["bag"]->inventory[object];
				p.Inventory["bag"]->inventory.erase(object);
				cout << "You have taken a " + object + " from your bag\n";
			}
			else
				cout << "There is no " + object + " in your bag\n";
		}
		else 
			cout << "You do not have a bag\n";
	}
	else if (container == "inventory")
		cout << "You can't take your " + object + " from your inventory. It's already in your possession\n";
	else
		cout << "You do not have a " + container + "\n";

	cout << endl;
}

PutCommand::PutCommand(string first)
{
	words.resize(4);
	words[0] = first;
}

void PutCommand::Execute(Player& p, string text[])
{
	if (text[1] != "")
	{
		if ((text[2] == "in") || (text[2] == "into"))
		{
			if (text[3] != "")
				Put(p, text[1], text[3]);
			else
				cout << "Invalid Command\n";
		}
		else
			cout << "Invalid Command\n";
	}
	else
		cout << "Invalid Command\n";
}

void PutCommand::Put(Player& p, string object, string container)
{
	if (p.Inventory.find(object) != p.Inventory.end())
	{
		if (container != "")
		{
			if (container == "bag")
			{
				if (p.Inventory.find("bag") != p.Inventory.end())
				{
					p.Inventory["bag"]->inventory[object] = new Thing(object, p.Inventory[object]->description);
					p.Inventory.erase(object);
					cout << "You put your " + object + " in your bag\n";
				}
				else
					cout << "You do not have a bag\n";
			}
			else
				cout << "You do not have a " + container + "\n";
		}
		else
			cout << "You cannot put things in that\n";
	}
	else
		cout << "You do not have a " + object + "\n";

	cout << endl;
}

DropCommand::DropCommand(string first)
{
	words.resize(2);
	words[0] = first;
}

void DropCommand::Execute(Player& p, string text[])
{
	if ((text[1] != "inventory") && (text[1] != ""))
		Drop(p, text[1]);
	else
		cout << "Invalid Command\n";
}

void DropCommand::Drop(Player& p, string object)
{
	if (p.Inventory.find(object) != p.Inventory.end())
	{
		p.location.inventory[object] = p.Inventory[object];
		p.Inventory.erase(object);
		cout << "You have dropped your " + object + "\n";
	}
	else
		cout << "You don't have a " + object + "\n";

	cout << endl;
}

AttackCommand::AttackCommand(string first)
{
	words.resize(4);
	words[0] = first;
}

void AttackCommand::Execute(Player& p, string text[])
{
	if (text[1] != "")
	{
		if (text[2] != "with")
			AttackWith(p, text[1], "");
		else
		{
			if (text[3] != "")
				AttackWith(p, text[1], text[3]);
			else
				cout << "Invalid Command\n";
		}	
	}
	else
		cout << "Invalid Command\n";
}

void AttackCommand::AttackWith(Player& p, string enemy, string object)
{
	srand(time(0));
	if ((p.location.enemies.find(enemy) != p.location.enemies.end()) || (enemy == "all"))
	{
		if (object != "")
		{
			if (p.Inventory.find(object) != p.Inventory.end())
			{
				if (p.Inventory[object]->components.find("damage") != p.Inventory[object]->components.end())
				{
					if (p.Inventory[object]->components["damage"]->damage > 0)
					{
						if (enemy != "all")
						{
							blackboard.Add(Message(p.Inventory[object], p.location.enemies[enemy], "damage", p.Inventory[object]->components["damage"]->damage));
							blackboard.Run();

							blackboard.Add(Message(p.location.enemies[enemy], p, "damage", rand() %5 + 1));
							if ((p.location.enemies[enemy].components["attackable"]->alive == true) && (p.components["attackable"]->alive == true))
								blackboard.Run();
							else
								blackboard.Remove();
						}
						else
						{
							vector<Enemy> enemies;
							for (map<string, Enemy>::iterator it = p.location.enemies.begin(); it != p.location.enemies.end(); ++it)
								enemies.push_back(it->second);

							Announcement(p.Inventory[object], enemies, "damage", p.Inventory[object]->components["damage"]->damage);

							for (map<string, Enemy>::iterator it = p.location.enemies.begin(); it != p.location.enemies.end(); ++it)
							{
								blackboard.Add(Message(it->second, p, "damage", rand() %3 + 1));

								if ((p.location.enemies[it->second.name].components["attackable"]->alive == true) && (p.components["attackable"]->alive == true))	
									blackboard.Run();
								else
									blackboard.Remove();
							}
						}
					}
				}
				else
					cout << "You cannot attack with a "  + object + "\n";
			}
			else
				cout << "You do not have a " + object + "\n";
		}
		else
		{
			if (enemy != "all")
			{
				Message(p, p.location.enemies[enemy], "damage", 1);

				if ((p.location.enemies[enemy].components["attackable"]->alive == true) && (p.components["attackable"]->alive == true))
					blackboard.Add(Message(p.location.enemies[enemy], p, "damage", rand() %3 + 1));

				blackboard.Run();
			}
			else
			{
				vector<Enemy> enemies;
				for (map<string, Enemy>::iterator it = p.location.enemies.begin(); it != p.location.enemies.end(); ++it)
					enemies.push_back(it->second);

				Announcement(p, enemies, "damage", 1);

				for (map<string, Enemy>::iterator it = p.location.enemies.begin(); it != p.location.enemies.end(); ++it)
				{
					blackboard.Add(Message(it->second, p, "damage", rand() %3 + 1));

					p.location.enemies[it->second.name].components["attackable"]->alive = it->second.components["attackable"]->alive;

					if ((p.location.enemies[it->second.name].components["attackable"]->alive == true) && (p.components["attackable"]->alive == true))	
						blackboard.Run();
					else
						blackboard.Remove();
				}

				//for (vector<Enemy>::iterator it = enemies.begin(); it != enemies.end(); ++it)
					//p.location.enemies[it->name].components["attackable"]->alive = it->components["attackable"]->alive;
			}
		}
	}
	else
		cout << "There is no " + enemy + " for you to attack here\n";

	if (p.location.enemies.find(enemy) != p.location.enemies.end())
	{
		if (p.location.enemies[enemy].components["attackable"]->alive == false)
			p.location.enemies.erase(enemy);
	}

	cout << endl;
}

CommandProcessor::CommandProcessor()
{
	GoCommand* g = new GoCommand("go");
	LookCommand* l = new LookCommand("look");
	TakeCommand* t = new TakeCommand("take");
	PutCommand* p = new PutCommand("put");
	DropCommand* d = new DropCommand("drop");
	AttackCommand* a = new AttackCommand("attack");

	commands.push_back(g);
	commands.push_back(l);
	commands.push_back(t);
	commands.push_back(p);
	commands.push_back(d);
	commands.push_back(a);
}


void CommandProcessor::Execute(Player& p, string text[])
{
	for (int i = 0; i < commands.size(); i++)
	{
		if (commands[i]->words[0] == text[0])
		{
			commands[i]->Execute(p, text);
		}
	}
}