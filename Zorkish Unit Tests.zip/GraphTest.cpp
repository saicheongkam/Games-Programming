#include "stdafx.h"
#include "Player.h"
#include "Graph.h"
#include "CommandProcessor.h"
#include "CppUnitTest.h"
#include <string>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ZorkishTest
{		
	TEST_CLASS(GraphTest)
	{
	public:
		
		TEST_METHOD(ChangeLocation)
		{
			Player p = Player();
			Graph g = Graph("Grass World");
			CommandProcessor cp = CommandProcessor();

			p.location = g.nodes[1];
			
			Assert::AreEqual(p.location.name, (std::string)"Lush Meadow.");

			std::string command[] = {"go", "north"};
			cp.Execute(p, command);

			Assert::AreEqual(p.location.name, (std::string)"Valley.");

			std::string command2[] = {"go", "south"};
			cp.Execute(p, command2);	//go south once
			cp.Execute(p, command2);	//go south twice

			Assert::AreEqual(p.location.name, (std::string)"Forest.");
		}

		TEST_METHOD(NotChangeLocation)
		{
			Player p = Player();
			Graph g = Graph("Grass World");
			CommandProcessor cp = CommandProcessor();

			p.location = g.nodes[1];
			
			Assert::AreEqual(p.location.name, (std::string)"Lush Meadow.");

			std::string command[] = {"go", "north"};
			cp.Execute(p, command);

			Assert::AreEqual(p.location.name, (std::string)"Valley.");

			std::string command2[] = {"go", "north"};
			cp.Execute(p, command2);

			Assert::AreEqual(p.location.name, (std::string)"Valley.");
		}

	};
}