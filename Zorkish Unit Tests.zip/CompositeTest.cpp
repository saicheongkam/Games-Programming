#include "stdafx.h"
#include "Player.h"
#include "Graph.h"
#include "Item.h"
#include "CommandProcessor.h"
#include "CppUnitTest.h"
#include <string>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ZorkishTest
{		
	TEST_CLASS(CompositeTest)
	{
	public:
		
		TEST_METHOD(TakeItem)
		{
			Player p = Player();
			Graph g = Graph("Grass World");
			CommandProcessor cp = CommandProcessor();

			p.location = g.nodes[1];
			Assert::IsTrue(p.location.inventory.find("sword") != p.location.inventory.end());	//in location
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//not in inventory

			std::string command[] = {"take", "sword"};
			cp.Execute(p, command);
			Assert::IsTrue(p.location.inventory.find("sword") == p.location.inventory.end());	//not in location
			Assert::IsTrue(p.Inventory.find("sword") != p.Inventory.end());		//in inventory
		}

		TEST_METHOD(DropItem)
		{
			Player p = Player();
			Graph g = Graph("Grass World");
			CommandProcessor cp = CommandProcessor();

			p.location = g.nodes[1];
			
			Assert::IsTrue(p.location.inventory.find("sword") != p.location.inventory.end());	//in location
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//not in inventory

			std::string command[] = {"take", "sword"};
			cp.Execute(p, command);
			Assert::IsTrue(p.location.inventory.find("sword") == p.location.inventory.end());	//not in location
			Assert::IsTrue(p.Inventory.find("sword") != p.Inventory.end());		//in inventory

			std::string command2[] = {"drop", "sword"};
			cp.Execute(p, command2);
			Assert::IsTrue(p.location.inventory.find("sword") != p.location.inventory.end());	//in location again
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//not in inventory again
		}

		TEST_METHOD(PutInBag)
		{
			Player p = Player();
			Graph g = Graph("Grass World");
			CommandProcessor cp = CommandProcessor();

			p.location = g.nodes[1];
			
			Assert::IsTrue(p.location.inventory.find("sword") != p.location.inventory.end());	//in location
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//not in inventory

			std::string command[] = {"take", "sword"};
			cp.Execute(p, command);
			Assert::IsTrue(p.location.inventory.find("sword") == p.location.inventory.end());	//not in location
			Assert::IsTrue(p.Inventory.find("sword") != p.Inventory.end());		//in inventory

			std::string command2[] = {"put", "sword", "in", "bag"};
			cp.Execute(p, command2);
			Assert::IsTrue(p.location.inventory.find("sword") == p.location.inventory.end());	//not in location
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//not in inventory
			Assert::IsTrue(p.Inventory["bag"]->inventory.find("sword") != p.Inventory["bag"]->inventory.end());		//in bag
		}

		TEST_METHOD(DropBag)
		{
			Player p = Player();
			Graph g = Graph("Grass World");
			CommandProcessor cp = CommandProcessor();

			p.location = g.nodes[1];
			
			Assert::IsTrue(p.location.inventory.find("sword") != p.location.inventory.end());	//in location
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//not in inventory

			std::string command[] = {"take", "sword"};
			cp.Execute(p, command);
			Assert::IsTrue(p.location.inventory.find("sword") == p.location.inventory.end());	//not in location
			Assert::IsTrue(p.Inventory.find("sword") != p.Inventory.end());		//in inventory

			std::string command2[] = {"put", "sword", "in", "bag"};
			cp.Execute(p, command2);
			Assert::IsTrue(p.location.inventory.find("sword") == p.location.inventory.end());	//not in location
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//not in inventory
			Assert::IsTrue(p.Inventory["bag"]->inventory.find("sword") != p.Inventory["bag"]->inventory.end());		//in bag
		
			std::string command3[] = {"drop", "bag"};
			cp.Execute(p, command3);
			Assert::IsTrue(p.location.inventory.find("sword") == p.location.inventory.end());	//sword not in location
			Assert::IsTrue(p.location.inventory.find("bag") != p.location.inventory.end());		//bag in location
			Assert::IsTrue(p.Inventory.find("sword") == p.Inventory.end());		//sword not in inventory
			Assert::IsTrue(p.Inventory.find("bag") == p.Inventory.end());		//bag not in inventory
			Assert::IsTrue(p.location.inventory["bag"]->inventory.find("sword") != p.location.inventory["bag"]->inventory.end());	//in bag
		}

	};
}