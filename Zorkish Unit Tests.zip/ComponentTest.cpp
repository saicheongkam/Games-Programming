#include "stdafx.h"
#include "Player.h"
#include "Graph.h"
#include "CommandProcessor.h"
#include "CppUnitTest.h"
#include <string>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ZorkishTest
{		
	TEST_CLASS(ComponentTest)
	{
	public:
		
		TEST_METHOD(ChangeLocation)
		{
			Player p = Player();
			Graph g = Graph("Grass World");
			CommandProcessor cp = CommandProcessor();

			p.location = g.nodes[1];
			p.components["attackable"]->health = 100;

			std::string command[] = {"go", "north"};
			cp.Execute(p, command);

			Assert::IsTrue(p.location.enemies.find("pentaplantagon") != p.location.enemies.end());	//in location
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->alive == true);	//alive
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->health == 5);	//5 health

			std::string command2[] = {"attack", "pentaplantagon"};
			cp.Execute(p, command2);
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->health == 4);	//4 health
			cp.Execute(p, command2);
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->health == 3);	//3 health
			cp.Execute(p, command2);
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->health == 2);	//2 health
			cp.Execute(p, command2);
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->health == 1);	//1 health
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->alive == true);	//alive

			cp.Execute(p, command2);
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->health == 0);	//0 health
			Assert::IsTrue(p.location.enemies["pentaplantagon"].components["attackable"]->alive == false);	//dead
		}

	};
}